def product(x):
    t = 1
    for n in x:
        t *= n
    return t

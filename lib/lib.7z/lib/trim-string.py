# strip, lstrip, rstrip
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
s = "   Hello   "


print("<", s.strip(), ">")
# < Hello >


print("<", s.lstrip(), ">")
# < Hello    >


print("<", s.rstrip(), ">")
# <    Hello >
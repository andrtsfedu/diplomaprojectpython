# Use the correct short hand syntax to put the following statement on one line:


if 5 > 2:
    print("Five is greater than two!")

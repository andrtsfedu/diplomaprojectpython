my_list=["Hello","Pretty","World"]

print("".join(my_list))
print("@".join(my_list))
print(" ".join(my_list))
print(",".join(my_list))
print("-".join(my_list))
print("--".join(my_list))
print("---".join(my_list))
print("=".join(my_list))
print("==".join(my_list))
print(" My ".join(my_list))

"""
HelloPrettyWorld
Hello@Pretty@World
Hello Pretty World
Hello,Pretty,World
Hello-Pretty-World
Hello--Pretty--World
Hello---Pretty---World
Hello=Pretty=World
Hello==Pretty==World
Hello My Pretty My World
"""
import random
A= random.randint (1,100)
print("Number:" + str(A))

if A % 2 == 0:
    print ("The number is even")
    
if A % 10 == 0:
    print ("The number is a multiple of 10")

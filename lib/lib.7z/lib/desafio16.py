from math import trunc
num = float(input('Digite um número: '))
print('O número {} tem a parte inteira {}.'.format(num, trunc(num)))

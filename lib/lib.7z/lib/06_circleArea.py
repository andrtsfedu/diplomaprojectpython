# Make a Program that asks for the radius of a circle, calculate and show its area.


circleRadius = float(input("Insert the circle's area: "))

area = 3.14 * (circleRadius**2)

print(f'\nThe area is {area:.2f}')
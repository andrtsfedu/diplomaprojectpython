A = True 
B = False
if A &amp; B or A != B :
    print("it works")

#!/usr/bin/env python3
#coding: utf-8
"""
pythonic way
"""

lst = [1,1,5,4,9,7,4,5,8,3,9]
res = list(set(lst))
res.sort()
print(res)



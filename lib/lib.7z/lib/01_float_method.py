# Instructions: Insert the correct syntax to convert x into a floating point number.
x = 5
# Solution: float()
x = float(x)

print(x)
'''
The float() method can be used to transform an int to float.
Read more here: https://www.w3schools.com/python/python_numbers.asp
'''

# Instructions: Display the sum of 5 + 10, using two variables: x and y.

# Solution: 
x = 5
y = 10
print(x + y)

'''
What I'm doing here is starting the int variable "x" and assigning it the int value "5" with the "=".
Then I assign the int value of 10 to the "y" and print in console the sum of both variables.
Read more here: https://www.w3schools.com/python/python_variables.asp
'''
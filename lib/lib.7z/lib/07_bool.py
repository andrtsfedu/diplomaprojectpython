# Instructions: The following code example would print the data type of x, what data type would that be?
x = True
print(type(x))

'''
Solution:
bool
Booleans values are bool type.https://www.w3schools.com/python/python_datatypes.asp
'''

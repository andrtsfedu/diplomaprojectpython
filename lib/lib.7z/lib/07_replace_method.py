# Instruction: Replace the character H with a J.
txt = "Hello World"
# Solution:
txt = txt.replace("H", "J")
print(txt)
# Read More Here: https://www.w3schools.com/python/python_strings.asp

a=15.0
b=1024.0
kb=(15.0/1024.0)
mb=(15.0/1024.0/1024.0)
print("kilobyte -",kb)
print("megabyte -",mb)

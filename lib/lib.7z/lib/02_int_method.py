# Instructions: Insert the correct syntax to convert x into a integer.
x = 5.5
# Solution: int()
x = int(x)

print(x)

'''
The int() method can be used to transform a float to an int.
Read more here: https://www.w3schools.com/python/python_numbers.asp
'''

# your code here

color = "Yellow"
print(color)
# What is the correct syntax of printing all variables and function names of the "mymodule" module?

# import mymodule

# print(dir(mymodule))

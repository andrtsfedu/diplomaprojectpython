#!/usr/bin/env python3
#coding: utf-8
"""
1. Напишите программу, которая 10 раз выводит на экран Ваши имя
"""

for i in range(0, 10):
    print('Alexey')
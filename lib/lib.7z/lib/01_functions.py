# Create a function named my_function.

def my_function():
    print("Hello from a function")

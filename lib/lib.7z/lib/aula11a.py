from cor import cores
print('{}Olá Mundo!{}'.format(cores['amarelo'], cores['limpa']))

import random 
A=random.randint(-100,100)
print("A= " + str(A))
if A > 0 :
    print("Positive number")
    
if A < 0 :
    print("Negative number")
    
if A == 0 :
    print("Number is zero")

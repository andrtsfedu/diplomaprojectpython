class Parent:
    pass

class Child(Parent):
    pass
#!/usr/bin/env python3
#coding: utf-8

print("'Соловей' - птица певчая")
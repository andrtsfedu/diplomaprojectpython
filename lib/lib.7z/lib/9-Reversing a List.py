my_list = range(1, 11)

# Add your code below!
backwards = my_list[::-1]
print backwards

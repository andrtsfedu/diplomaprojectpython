# Print "Hello" if a is equal to b, or if c is equal to d.

a, b, c, d = 1, 1, 1, 1


if a == b or c == d:
    print("Hello")

# Instructions: Create a variable named carname and assign the value Volvo to it.

# Solution:
carname = "Volvo"

'''
What I'm doing here is starting the string variable "carname" and assigning it the string value "Volvo" with the "=".
Read more here: https://www.w3schools.com/python/python_variables.asp and https://www.w3schools.com/python/python_variables_names.asp
'''
import emoji
print(emoji.emojize('Olá, Mundo! :earth_americas:', use_aliases=True))

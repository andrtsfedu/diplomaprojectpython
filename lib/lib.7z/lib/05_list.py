s = "Hello"
c = ["H", 2, "Hello"]
print(c)
print(c[1])
print(type(c[1]))
print(type(c[0]))
print(c[:2])
print(s[:2])
print(dir(list))
# print(help(c.remove()))



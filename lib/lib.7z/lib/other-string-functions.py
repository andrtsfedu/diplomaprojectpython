print("Hello\tWorld".expandtabs(2))
# Hello World

print("Hello\tWorld".expandtabs(8))
# Hello   World

print("Hello\tWorld".expandtabs(16))
# Hello           World

print("Hello\tWorld".expandtabs(32))
# Hello                           World
to_21 = range(1,22)

odds = to_21[::2]

middle_third = to_21[7:14]

print to_21
print odds
print middle_third

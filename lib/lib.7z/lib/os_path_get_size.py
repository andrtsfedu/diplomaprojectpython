import os
import sys

p = os.path.join(sys.path[0], "os_mk_dir.py")
print(os.path.getsize(p))

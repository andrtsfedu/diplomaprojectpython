# Print "Hello" if a is equal to b, and c is equal to d.

a = 1
b = 1
c = 1
d = 1

if a == b and c == d:
    print("Hello")

# If one of these is defined for a class, it is a descriptor.
# __getters__()
# __setters__()
# __delete__()

# There is no private variable in python
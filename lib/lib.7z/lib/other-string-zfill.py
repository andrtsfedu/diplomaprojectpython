print("hello".zfill(20))
# 000000000000000hello
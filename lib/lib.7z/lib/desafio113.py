from utilidades.dado import leiaInt, leiaFloat

i = leiaInt('Digite um Inteiro: ')
f = leiaFloat('Digite um Real: ')
print(f'Número inteiro lido foi {i}')
print(f'Número real lido foi {f:.2f}')

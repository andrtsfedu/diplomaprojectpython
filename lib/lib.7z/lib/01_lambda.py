# Create a lambda function that takes one parameter (a) and returns it.

def x(a): return a

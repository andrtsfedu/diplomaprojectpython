# Make a program that converts meters to centimeters.


meterValue = float(input('Insert your meter value: '))

centimeter = meterValue * 100

print(f'\n{meterValue:.2f}m in centimeters is {centimeter:.2f}cm')
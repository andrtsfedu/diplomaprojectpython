c = "Hi There!"
print(c[0])
print(c[3])
print(type(c[0]))

print(c[-1])
print(c[-2])
print(c[0:2])  # Upper bound index not included
print(c[1:4])
print(c[3:])
print(c[-3:])




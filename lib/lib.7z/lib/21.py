import random

x = random.randint(-10,10)
print("x = " + str(x))

y = random.randint(-10,10)
print("y = " + str(y))

z = (1.0/(x*y))
print("z = " + str(z))

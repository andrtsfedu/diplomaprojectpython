import os
import sys

D = os.listdir(sys.path[0])

for d in D:
    print(d)

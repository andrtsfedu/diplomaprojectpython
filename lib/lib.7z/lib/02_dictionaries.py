# Change the "year" value from 1964 to 2020.

car = {
    "brand": "Ford",
    "model": "Mustang",
    "year": 1964
}

car["year"] = 2020

print(car)

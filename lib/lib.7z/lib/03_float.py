# Instructions: The following code example would print the data type of x, what data type would that be?
x = 20.5
print(type(x))

'''
Solution: 
float
The inexact numbers are float type. Read more here: https://www.w3schools.com/python/python_datatypes.asp
'''
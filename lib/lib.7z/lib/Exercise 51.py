print("Arithmetic Progression")
print("-"*22)
num1 = int(input("First number: "))
num2 = int(input("Second number: "))
for a in range(0, 10):
    print(num1)
    num1 = num1 + num2

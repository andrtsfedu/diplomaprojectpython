r = range(10)
print(r, type(r))

# Output:
"""
range(0, 10) <class 'range'>
"""

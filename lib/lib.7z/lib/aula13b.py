soma = 0
for c in range(0, 3):
    n = int(input('Digite um valor inteiro: '))
    soma += n
print('Somatório dos valores foi {}.'.format(soma))

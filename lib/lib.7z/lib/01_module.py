# What is the correct syntax to import a module named "mymodule"?
# import mymodule

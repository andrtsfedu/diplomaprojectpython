# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Simple function
def my_function():
    print("this is a function")


my_function()
my_function()
my_function()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Function with arguments
def calculate(a,b,c):
    return a*b*c

print(calculate(12,13,14))
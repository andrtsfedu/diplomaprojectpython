# Instruction: Convert the value of txt to upper case.
txt = "Hello World"
# Solution: upper() method convert  the text to uppercase
txt = txt.upper()
print(txt)
# Read More Here: https://www.w3schools.com/python/python_strings.asp

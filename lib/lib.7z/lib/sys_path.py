import sys

for p in sys.path:
    print(p)

print("-"*30)
print(sys.path[0])

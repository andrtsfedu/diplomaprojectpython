meal = 44.50
tax = 0.0675

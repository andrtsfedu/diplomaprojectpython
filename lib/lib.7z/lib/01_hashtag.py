# Instructions: Comments in Python are written with a special character, which one?

# Solution:
# This is a comment

''' 
# Are used for single line comments
Read More Here: https://www.w3schools.com/python/python_comments.asp
'''
a = 1
b = "2"
c = 3
print(int(2.5))
print(a + float(b))
print(c)
print(c/0)

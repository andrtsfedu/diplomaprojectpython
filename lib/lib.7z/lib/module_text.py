# This is our new custom module

def first_module_function():
    print("This is the function from my custom module")
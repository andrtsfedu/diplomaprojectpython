# programa que leia duas notas de um aluno e calcule a sua média

print('==ESCOLINHA==')

nota1 = float(input('Digite a primeira nota: '))
nota2 = float(input('Digite a segunda nota: '))
media = (nota1 + nota2) / 2

print('A média é {:.2f}'.format(media))

# deu certo 🥳 (tentativa antes de assistir à aula)

# correção do professor
# n1 = float(input('Primeira nota do aluno: '))
# n2 = float(input('Segunda nota do aluno: '))
# média = (n1 + n2) / 2
# print('A média entre {} e {} é igual a {}'.format(n1, n2, média)

# Instructions: Insert the correct syntax to add a placeholder for the age parameter.
age = 36
# Solution:
txt = "My name is John, and I am {}"
print(txt.format(age))
# Read More Here: https://www.w3schools.com/python/python_strings.asp

# programa que leia um número inteiro e mostre na tela o seu sucessor e antecessor
inteiro = int(input('Digite um número inteiro: '))

print('O número:{} \n o antecessor: {} \n o sucessor: {}'.format(inteiro, inteiro - 1, inteiro + 1))

# deu certo! 🥳 (versão ainda sem assistir a aula do exercício)

# do professor:
# n = int(input('Digite um número: '))
# print('Analisando o valor {}, seu antecessor é {} e o sucessor é {}'.format(n, (n - 1), (n + 1)))
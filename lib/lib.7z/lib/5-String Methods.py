parrot = "Norwegian Blue"
print len(parrot)

# import playsound
# playsound('Path of the file')


"""
if you want to try this code by your own in your PC 
make sure to install the playsound package, version 1.2.2
the newest versions for some reason it isn't in Python 3.10
and if it stills not working, try downgrade the Python version to 3.7 or 3.8.
and install the playsound package by 'pip install playground' command
"""

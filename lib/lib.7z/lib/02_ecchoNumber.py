# Make a program that asks for a number and then displays the message "The number entered was [number]".


number = int(input('Pass a number: '))

print(f'\nThe number entered is {number}')
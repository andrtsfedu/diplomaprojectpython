#!/usr/bin/env python3
#coding: utf-8
"""
pythonic way
"""

lst = ['aaabb', 'caca', 'dabc', 'acc', 'abbb']
res = ','.join(lst)
print(res)

s = "hello"

print(len(s))

# 5

# TUPLAS SÃO IMUTÁVEIS!!!
lanche = ('Hamburger', 'Suco', 'Pizza', 'Pudim')

# Erro, não pode existir subst. em TUPLA
lanche[1] = 'Refrigerante'

print(lanche[1])

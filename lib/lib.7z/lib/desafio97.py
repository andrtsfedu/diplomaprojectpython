def escreva(txt):
    tam = len(txt)
    print('~' * (tam + 4))
    print(f'  {txt:}')
    print('~' * (tam + 4))


# Programa principal
escreva('Matheus Percario')
escreva('Oi')
escreva('Oi eu sou o matheus percario bruder e estou aprendendo a linguagem de programação python!')

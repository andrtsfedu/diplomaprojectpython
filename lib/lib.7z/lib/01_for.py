# Loop through the items in the fruits list.

fruits = ["apple", "banana", "cherry"]
for x in fruits:
    print(x)

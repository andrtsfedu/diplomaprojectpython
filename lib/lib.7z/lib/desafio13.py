salario = float(input('Digite o salario do funcionario: '))
print('\nSalario atual -> R$ {:.2f}'.format(salario))
print('Novo salario (Reajuste +5%) -> R$ {:.2f}'.format(salario*1.15))
